<?php
/**
 * @author    校长bloG <1213235865@qq.com>
 * @github    https://github.com/vpsaz/ysss
 */

return array (
  'site_title' => '影视搜索',
  'site_description' => '校长影视搜索',
  'site_keywords' => '影视搜索,电影,电视剧,网剧',
  'redirect_url' => '请使用浏览器访问网址',
  'player_api_prefix' => 'api.php?url=',
  'background_image_url' => 'https://pic1.imgdb.cn/item/6812a7ae58cb8da5c8d5cbab.png',
  'source_count' => '6',
  'baiapi_key' => '',
  'disclaimers' => '本站所有内容均来自互联网，本站不会保存、复制或传播任何视频文件，也不对本站上的任何内容负法律责任。如果本站部分内容侵犯您的版权请告知，在必要证明文件下我们第一时间撤除。',
  'announcement' => '<div style="text-align: center;">
<script id="LA-DATA-WIDGET" crossorigin="anonymous" charset="UTF-8" src="https://v6-widget.51.la/v6/这填写你的掩码ID/quote.js?theme=0&f=12&display=0,0,1,1,0,0,1,0"></script>
</div>

<script charset="UTF-8" id="LA_COLLECT" src="//sdk.51.la/js-sdk-pro.min.js"></script>
<script>LA.init({id:"这填写你的掩码ID",ck:"这填写你的掩码ID"})</script>

<div id="cc-myssl-id" style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;">
<a href="https://myssl.com/这填写你的域名?from=mysslid"><img src="https://static.myssl.com/res/images/myssl-id.png" alt="" style="width:100%;height:100%"></a>
</div>',
  'admin_password' => '123456',
  'bofang_api' => 'api.php?url=',
  'description' => '校长影视搜索',
  'keywords' => '影视搜索,电影,电视剧,网剧',
);
